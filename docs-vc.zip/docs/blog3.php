
<?php
/* Template Name: Blog3 Page */
get_header();
?>
<div class="about_top blog-feature">
</div>

<div class="post-filter-panel">
	<div class="container">

		<div class="separate">
				<?php $categories = get_categories(); ?>
				<ul class="cat-list">
				  <li><a class="cat-list_item active" href="javascript:void(0)" data-slug="">All projects</a></li>
				  <li><a class="cat-list_item " href="javascript:void(0)" data-slug="webinar">Webinar</a></li>
				  <li><a class="cat-list_item " href="javascript:void(0)" data-slug="insights">Insights</a></li>
				  <li><a class="cat-list_item " href="javascript:void(0)" data-slug="podcast">Podcast</a></li>
				  <li><a class="cat-list_item " href="javascript:void(0)" data-slug="interview">Interview</a></li>
				  <li><a class="cat-list_item " href="javascript:void(0)" data-slug="news">News</a></li>
				</ul>
				<div class="search-panel">
						<?php 
							if ( function_exists( 'wpes_search_form' ) ) {
								wpes_search_form( array( 
									'wpessid' => 5876 
								) );
							}	
						?>
				</div>

			</div>

			<div class="blog_listing">

					<?php 
					  $projects = new WP_Query([
					    'post_type' => 'post',
					    'posts_per_page' => -1,
					    'order_by' => 'date',
					    'order' => 'desc',
					  ]);
					?>

					<?php if($projects->have_posts()): ?>
					  <div class="project-tiles row">
					    <?php
					      while($projects->have_posts()) : $projects->the_post();
					        ?>
					        <div class="col-md-4">
					        	<a href="<?php the_permalink(); ?>">
					        	<figure><?php the_post_thumbnail(); ?></figure>
					        	<h3><?php the_title(); ?></h3>
					        	<div>
					        		
					        	</div>
					        	<span class="dates"><?php echo get_the_date( 'M d, Y ' ); ?> | <?php echo get_the_time( 'h:i a'); ?> </span>
					        	</a>
					        </div>
							<?php 
					      endwhile;
					    ?>
					  </div>
					  <?php wp_reset_postdata(); ?>
					<?php endif; ?>

			</div>

	</div>
</div>

<?php get_footer(); ?>

<script type="text/javascript">
		jQuery('.cat-list_item').on('click', function() {
	  jQuery('.cat-list_item').removeClass('active');
	  jQuery(this).addClass('active');

	  jQuery.ajax({
	    type: 'POST',
	    url: '/wp-admin/admin-ajax.php',
	    dataType: 'html',
	    data: {
	      action: 'filter_projects',
	      category: jQuery(this).data('slug'),
	    },
	    success: function(res) {
	      jQuery('.project-tiles').html(res);
	    }
	  })
	});
</script>

<style>
	.page-template-blog3 .menu span, .page-template-blog3 .menu span::before, .page-template-blog3 .menu span::after {
	    background-color: #ffffff;
	}
	.page-template-blog3 #footer{
		display: none !important;
	}
	header.header {
    position: relative !important;
	    top: 0px !important;
	  }
	.blog-feature {
	    margin-top: -109px !important;
	}
	h3.not-found{
		display: block !important;
		text-align: center !important;
		width: 100% !important;
	}
	.post-filter-panel{
		padding: 50px 0;
	}
	.separate{
		display: flex;
		align-items: center;
		justify-content: space-between;
		margin-bottom: 50px;
	}
	.cat-list{
		display: flex;
		align-items: center;
		flex-wrap: wrap;
	}
	.cat-list li{
		margin-right: 10px;
	}
	.cat-list li a{
    padding: 6px 10px;
    background: #ffffff;
    border-radius: 5px;
    font-weight: 700;
    display: block;
	}
	.cat-list li a.active{
		background: #000000;
		color: #ffffff !important;
	}
	.search-panel{
    display: flex;
    align-items: center;
    justify-content: flex-end;
    position: relative;
	}
	.search-panel form label{
		width: 300px;
		height: 50px;
	}
	.search-panel input[type="search"]{
		margin: 0;
		height: 40px;
		border: none;
		padding: 5px 15px;
	}
	.search-panel input[type="submit"]{
		margin: 0;
		font-size: 13px;
		padding: 0 15px;
		border: none;
		height: 40px;
	}
	.blog_listing h3{
		color: #777;
		font-size: 17px;
		font-family: 'gothambold';
		margin-top: 7px;
		font-weight: 700;
		min-height: 45px;
		line-height: 26px;
	}
	.project-tiles.row{
		display: flex;
    flex-wrap: wrap;
	}
	.project-tiles.row > div{
		margin-bottom: 30px;
	}
	.project-tiles img{
		max-width: 100%;
		height: auto;
		object-fit: cover;
		border-radius: 15px;
	}
	.project-tiles .dates{
	    font-size: 14px;
	    line-height: 30px;
	    color: #535353;
	    text-transform: uppercase;
	    font-weight: 700;
	    font-family: 'gothambold';
	    display: flex;
	}
	.m-1{
		margin: 0 3px;
	}

	@media (max-width: 1199px) {
		.separate{
			flex-direction: column;
		}
		.cat-list {
			margin-bottom: 25px;
			justify-content: space-around;
		}
		.cat-list li {
			margin-bottom: 15px;		}
	}

	@media (max-width: 991px) {
		.post-filter-panel{}
		.post-filter-panel .container{
			max-width: 100%;
		}
		.project-tiles.row > div {
		    width: 50%;
		}
	}

	@media (max-width: 767px) {
		.project-tiles.row > div {
		    width: 100%;
		}
		.blog_listing h3 {
		    min-height: auto;
		}
		.project-tiles img {
		    height: auto;
		}
		.cat-list {
		    margin-bottom: 0px;
		}
		.cat-list li a {
		    font-size: 15px;
		}
		.blog-feature {
		    margin-top: -40px !important;
		}
	}
	@media (max-width: 576px) {
		.search-panel form label {
		    width: 100%;
		    height: 50px;
		}
		.post-filter-panel {
		    padding: 30px 0;
		}
		.separate {
		    margin-bottom: 30px;
		}
		.cat-list li {
		    margin-right: 0;
		    width: 31%;
		}
		.cat-list li a{
			text-align: center;
		}
		.post-filter-panel .search-form {
		    margin: 0;
		}
	}


</style>
