<?php
/*
	@ Function file
	@ Contains custom post type
	@ Theme options
	@ Created by Sanoj
*/
function vcommission_enqueue_styles() {
  wp_enqueue_style( 'bootstrap', get_stylesheet_directory_uri() . '/css/bootstrap.min.css' );
  wp_enqueue_style( 'fullpage', get_stylesheet_directory_uri() . '/css/fullpage.css' );
  wp_enqueue_style( 'human', get_stylesheet_directory_uri() . '/css/human.css' );
  wp_enqueue_style( 'aos', get_stylesheet_directory_uri() . '/css/aos.css' );
  wp_enqueue_style( 'owl', get_stylesheet_directory_uri() . '/css/owl.carousel.min.css' );
  $parenthandle = 'parent-style'; // This is 'twentyfifteen-style' for the Twenty Fifteen theme.
  $theme = wp_get_theme();
}
add_action( 'wp_enqueue_scripts', 'vcommission_enqueue_styles', 5 );

function vcommission_responsive_styles() {
  wp_enqueue_style( 'responsive', get_stylesheet_directory_uri() . '/css/responsive.css?v=1.3' );
}
add_action( 'wp_enqueue_scripts', 'vcommission_responsive_styles', 20 );

function child_theme_styles() {
  $parent_style = 'parent-style';
  wp_enqueue_style( 'child-style', get_stylesheet_directory_uri() . '/style.css?v=1.0.24', array( $parent_style ) );
}
add_action( 'wp_enqueue_scripts', 'child_theme_styles', 6 );

function my_custom_scripts() {
  wp_enqueue_script( 'jquery-js', get_stylesheet_directory_uri() . '/js/jquery-2.1.4.min.js', array( 'jquery' ), '', true );
  wp_enqueue_script( 'fullpage-js', get_stylesheet_directory_uri() . '/js/fullpage.js', array( 'jquery' ), '', true );
  wp_enqueue_script( 'bootstrap-js', get_stylesheet_directory_uri() . '/js/bootstrap.min.js', array( 'jquery' ), '', true );
  wp_enqueue_script( 'aos-js', get_stylesheet_directory_uri() . '/js/aos.js', array( 'jquery' ), '', true );
  wp_enqueue_script( 'particle-js', get_stylesheet_directory_uri() . '/js/particles.min.js', array( 'jquery' ), '', true );
  wp_enqueue_script( 'app-js', get_stylesheet_directory_uri() . '/js/app.js', array( 'jquery' ), '', true );
  wp_enqueue_script( 'owl-js', get_stylesheet_directory_uri() . '/js/owl.carousel.min.js', array( 'jquery' ), '', true );
  wp_enqueue_script( 'counter-js', get_stylesheet_directory_uri() . '/js/counter.js', array( 'jquery' ), '', true );
  wp_enqueue_script( 'bubble-js', get_stylesheet_directory_uri() . '/js/bubble.js', array( 'jquery' ), '', true );
  wp_enqueue_script( 'human-js', get_stylesheet_directory_uri() . '/js/human.js', array( 'jquery' ), '', true );
}
add_action( 'wp_enqueue_scripts', 'my_custom_scripts' );

if ( !function_exists( 'custom_post_type' ) ) {

  // Register Custom Post Type
  function custom_post_type() {

    $labels = array(
      'name' => _x( 'Teams', 'Post Type General Name', 'text_domain' ),
      'singular_name' => _x( 'Team', 'Post Type Singular Name', 'text_domain' ),
      'menu_name' => __( 'Team', 'text_domain' ),
      'name_admin_bar' => __( 'Team', 'text_domain' ),
      'archives' => __( 'Item Archives', 'text_domain' ),
      'attributes' => __( 'Item Attributes', 'text_domain' ),
      'parent_item_colon' => __( 'Parent Item:', 'text_domain' ),
      'all_items' => __( 'All Items', 'text_domain' ),
      'add_new_item' => __( 'Add New Item', 'text_domain' ),
      'add_new' => __( 'Add New', 'text_domain' ),
      'new_item' => __( 'New Item', 'text_domain' ),
      'edit_item' => __( 'Edit Item', 'text_domain' ),
      'update_item' => __( 'Update Item', 'text_domain' ),
      'view_item' => __( 'View Item', 'text_domain' ),
      'view_items' => __( 'View Items', 'text_domain' ),
      'search_items' => __( 'Search Item', 'text_domain' ),
      'not_found' => __( 'Not found', 'text_domain' ),
      'not_found_in_trash' => __( 'Not found in Trash', 'text_domain' ),
      'featured_image' => __( 'Featured Image', 'text_domain' ),
      'set_featured_image' => __( 'Set featured image', 'text_domain' ),
      'remove_featured_image' => __( 'Remove featured image', 'text_domain' ),
      'use_featured_image' => __( 'Use as featured image', 'text_domain' ),
      'insert_into_item' => __( 'Insert into item', 'text_domain' ),
      'uploaded_to_this_item' => __( 'Uploaded to this item', 'text_domain' ),
      'items_list' => __( 'Items list', 'text_domain' ),
      'items_list_navigation' => __( 'Items list navigation', 'text_domain' ),
      'filter_items_list' => __( 'Filter items list', 'text_domain' ),
    );
    $args = array(
      'label' => __( 'Team', 'text_domain' ),
      'description' => __( 'Team page post types', 'text_domain' ),
      'labels' => $labels,
      'supports' => array( 'title', 'thumbnail', 'custom-fields' ),
      'taxonomies' => array( 'category' ),
      'hierarchical' => false,
      'public' => true,
      'show_ui' => true,
      'show_in_menu' => true,
      'menu_position' => 25,
      'show_in_admin_bar' => false,
      'show_in_nav_menus' => true,
      'can_export' => true,
      'has_archive' => true,
      'exclude_from_search' => true,
      'publicly_queryable' => true,
      'capability_type' => 'page',
      'show_in_rest' => true,
      'query_var' => true,
    );
    register_post_type( 'vcommission_team', $args );

  }
  add_action( 'init', 'custom_post_type', 0 );
}

// Add Shortcode
function vcom_team_shortcode() {
  global $post;
  $args = array(
    'post_type' => 'vcommission_team',
    'post_status' => 'publish',
    'posts_per_page' => -1,
  );
  $loop = new WP_Query( $args );
  $html = '<div class="owl-carousel owl-theme"  data-aos="fade-up" data-aos-duration="800">';
  while ( $loop->have_posts() ): $loop->the_post();
  $designation = get_post_meta( $post->ID, 'designation', true );
  $title = get_the_title();
  $html .= '<div class="item">
            <div class="col-sm-4">
              <div class="team_col">
                <div class="team_img"><img src="' . wp_get_attachment_url( get_post_thumbnail_id( $post->ID ) ) . '" alt="img" /></div>
                <div class="team_name">
                  <h3>' . $title . '</h3>
                  <p>' . $designation . '</p>
                </div>
              </div>
            </div>
          </div>';
  endwhile;
  wp_reset_postdata();
  $html .= '</div>';
  return $html;
}
add_shortcode( 'vcomteam', 'vcom_team_shortcode' );


if ( !function_exists( 'custom_post_type2' ) ) {

  // Register Custom Post Type
  function custom_post_type2() {

    $labels = array(
      'name' => _x( 'Testimonials', 'Post Type General Name', 'text_domain' ),
      'singular_name' => _x( 'Testimonial', 'Post Type Singular Name', 'text_domain' ),
      'menu_name' => __( 'Testimonial', 'text_domain' ),
      'name_admin_bar' => __( 'Testimonial', 'text_domain' ),
      'archives' => __( 'Item Archives', 'text_domain' ),
      'attributes' => __( 'Item Attributes', 'text_domain' ),
      'parent_item_colon' => __( 'Parent Item:', 'text_domain' ),
      'all_items' => __( 'All Items', 'text_domain' ),
      'add_new_item' => __( 'Add New Item', 'text_domain' ),
      'add_new' => __( 'Add New', 'text_domain' ),
      'new_item' => __( 'New Item', 'text_domain' ),
      'edit_item' => __( 'Edit Item', 'text_domain' ),
      'update_item' => __( 'Update Item', 'text_domain' ),
      'view_item' => __( 'View Item', 'text_domain' ),
      'view_items' => __( 'View Items', 'text_domain' ),
      'search_items' => __( 'Search Item', 'text_domain' ),
      'not_found' => __( 'Not found', 'text_domain' ),
      'not_found_in_trash' => __( 'Not found in Trash', 'text_domain' ),
      'featured_image' => __( 'Featured Image', 'text_domain' ),
      'set_featured_image' => __( 'Set featured image', 'text_domain' ),
      'remove_featured_image' => __( 'Remove featured image', 'text_domain' ),
      'use_featured_image' => __( 'Use as featured image', 'text_domain' ),
      'insert_into_item' => __( 'Insert into item', 'text_domain' ),
      'uploaded_to_this_item' => __( 'Uploaded to this item', 'text_domain' ),
      'items_list' => __( 'Items list', 'text_domain' ),
      'items_list_navigation' => __( 'Items list navigation', 'text_domain' ),
      'filter_items_list' => __( 'Filter items list', 'text_domain' ),
    );
    $args = array(
      'label' => __( 'Testimonial', 'text_domain' ),
      'description' => __( 'Testimonial page post types', 'text_domain' ),
      'labels' => $labels,
      'supports' => array( 'title', 'thumbnail' ),
      'taxonomies' => array( 'category' ),
      'hierarchical' => false,
      'public' => true,
      'show_ui' => true,
      'show_in_menu' => true,
      'menu_position' => 25,
      'show_in_admin_bar' => false,
      'show_in_nav_menus' => true,
      'can_export' => true,
      'has_archive' => true,
      'exclude_from_search' => true,
      'publicly_queryable' => true,
      'capability_type' => 'page',
    );
    register_post_type( 'testimonial', $args );
  }
  add_action( 'init', 'custom_post_type2', 0 );
}


if ( !function_exists( 'custom_post_article' ) ) {

  // Register Custom Post Type
  function custom_post_article() {

    $labels = array(
      'name' => _x( 'Articles', 'Post Type General Name', 'text_domain' ),
      'singular_name' => _x( 'Article', 'Post Type Singular Name', 'text_domain' ),
      'menu_name' => __( 'Article', 'text_domain' ),
      'name_admin_bar' => __( 'Article', 'text_domain' ),
      'archives' => __( 'Item Archives', 'text_domain' ),
      'attributes' => __( 'Item Attributes', 'text_domain' ),
      'parent_item_colon' => __( 'Parent Item:', 'text_domain' ),
      'all_items' => __( 'All Items', 'text_domain' ),
      'add_new_item' => __( 'Add New Item', 'text_domain' ),
      'add_new' => __( 'Add New', 'text_domain' ),
      'new_item' => __( 'New Item', 'text_domain' ),
      'edit_item' => __( 'Edit Item', 'text_domain' ),
      'update_item' => __( 'Update Item', 'text_domain' ),
      'view_item' => __( 'View Item', 'text_domain' ),
      'view_items' => __( 'View Items', 'text_domain' ),
      'search_items' => __( 'Search Item', 'text_domain' ),
      'not_found' => __( 'Not found', 'text_domain' ),
      'not_found_in_trash' => __( 'Not found in Trash', 'text_domain' ),
      'featured_image' => __( 'Featured Image', 'text_domain' ),
      'set_featured_image' => __( 'Set featured image', 'text_domain' ),
      'remove_featured_image' => __( 'Remove featured image', 'text_domain' ),
      'use_featured_image' => __( 'Use as featured image', 'text_domain' ),
      'insert_into_item' => __( 'Insert into item', 'text_domain' ),
      'uploaded_to_this_item' => __( 'Uploaded to this item', 'text_domain' ),
      'items_list' => __( 'Items list', 'text_domain' ),
      'items_list_navigation' => __( 'Items list navigation', 'text_domain' ),
      'filter_items_list' => __( 'Filter items list', 'text_domain' ),
    );
    $args = array(
      'label' => __( 'Article', 'text_domain' ),
      'description' => __( 'Article post types', 'text_domain' ),
      'labels' => $labels,
      'supports' => array( 'title', 'thumbnail' ),
      'taxonomies' => array( 'category' ),
      'hierarchical' => false,
      'public' => true,
      'show_ui' => true,
      'show_in_menu' => true,
      'menu_position' => 25,
      'show_in_admin_bar' => false,
      'show_in_nav_menus' => true,
      'can_export' => true,
      'has_archive' => true,
      'exclude_from_search' => true,
      'publicly_queryable' => true,
      'capability_type' => 'page',
    );
    register_post_type( 'article', $args );
  }
  add_action( 'init', 'custom_post_article', 0 );
}

/* Disable auto <p> tag in contact form 7 */
add_filter( 'wpcf7_autop_or_not', '__return_false' );

// Add Shortcode
function testimonials_shortcode( $atts ) {
  global $post;
  if ( empty( $atts[ 'category_name' ] ) ) {
    $atts[ 'category_name' ] = 'advertiser';
  }
  $args = array(
    'post_type' => 'testimonial',
    'post_status' => 'publish',
    'posts_per_page' => -1,
    'category_name' => $atts[ 'category_name' ]
  );

  $html = '';
  $loop = new WP_Query( $args );
  $html .= '<section class="gallary_sec party_gallary_sec" id="gallery_one">';
  $html .= '<div class="card-container">';
  $i = 0;
  $class = "";
  $html .= '<div class="card-row aos-init aos-animate" data-aos="fade-up" data-aos-duration="900">';
  while ( $loop->have_posts() ): $loop->the_post();
  $designation = get_post_meta( $post->ID, 'designation', true );
  $company = get_post_meta( $post->ID, 'company', true );
  $description = get_post_meta( $post->ID, 'description', true );
  $title = get_the_title();

  if ( $i % 2 == 0 ) {
    $class = $class == 'card' ? 'card-2' : 'card';
    if ( $i != 0 ) {
      $html .= '</div><div class="card-row aos-init aos-animate" data-aos="fade-up" data-aos-duration="900">';
    }
  }

  $html .= '<div class="' . $class . '">
                  <div class="inverted"><img src="https://vcommission.com/wp-content/uploads/2021/01/inverted.png" alt=""></div>
                  <div class="card-border">
                   <div class="card-content">
                    <h4>' . $title . '</h4>
                    <h6>' . $designation . '</h6>  
                    <h5>' . $company . '</h5>
                    <div class="card-hr"></div>
                    <p>' . $description . '</p></div></div>
                   <div class="card-img-box">
                      <div class="card-img-inner-box">
                        <img src="' . wp_get_attachment_url( get_post_thumbnail_id( $post->ID ) ) . '" alt="">
                      </div>
                   </div>
                  <div class="inverted-2"><img src="https://vcommission.com/wp-content/uploads/2021/01/inverted.png" alt=""></div>
                 </div>';
  $i++;
  endwhile;
  wp_reset_postdata();
  $html .= '</div></section>';
  return $html;
}
add_shortcode( 'testimonial', 'testimonials_shortcode' );



// Add Shortcode
function vc_articles_shortcode() {
  global $post;
  $args = array(
    'post_type' => 'article',
    'post_status' => 'publish',
    'posts_per_page' => -1,
  );

  $html = '';
  $loop = new WP_Query( $args );
  $html .= '<section class="gallary_sec party_gallary_sec" id="gallery_one">';
  $i = 0;
  $class = "card";
  $html .= '<div class="card-row aos-init aos-animate" data-aos="fade-up" data-aos-duration="900">';

  while ( $loop->have_posts() ): $loop->the_post();
  if ( $i % 3 == 0 ) {
    if ( $i != 0 ) {
      $html .= '</div><div class="card-row aos-init aos-animate" data-aos="fade-up" data-aos-duration="900">';
    }
  }
  $link = get_post_meta( $post->ID, 'article_link', true );
  $no_follow = get_post_meta( $post->ID, 'no_follow', true );
  $rel = "";
  if ( $no_follow[ 0 ] == 'Yes' ) {
    $rel = 'rel="nofollow"';
  }

  $description = get_post_meta( $post->ID, 'description', true );
  $title = get_the_title();
  $html .= '<div class="' . $class . '">
			  <div class="card-border">
			   <div class="card-content">
					<h4>' . $title . '</h4>
					<div class="card-hr"></div>
					<p>' . $description . '</p>
					<div class="read_more_aritlce"><a ' . $rel . ' href="' . $link . '" target="_blank">Read More</a></div>
				</div>
				</div>
			 </div>';
  $i++;
  endwhile;
  wp_reset_postdata();
  $html .= '</section>';
  return $html;
}
add_shortcode( 'vc_articles', 'vc_articles_shortcode' );

/** == SOCIAL MEDIA SHORT CODE **/
function social_link_shortcode() {
  $facebook = get_option( 'fb_link' );
  $facebook = !empty( $facebook ) ? $facebook : 'https://www.facebook.com/vcommission';
  $instgram = get_option( 'insta_link' );
  $instgram = !empty( $instgram ) ? $instgram : 'https://www.instagram.com/vcommission.enroute/?hl=en';
  $twitter = get_option( 'twitter_link' );
  $twitter = !empty( $twitter ) ? $twitter : 'https://twitter.com/vcommission';
  $linkedin = get_option( 'linkedin_link' );
  $linkedin = !empty( $linkedin ) ? $linkedin : 'https://linkedin.com/company/vc-internet-media-pvt.-ltd.';
  $youtube = get_option( 'youtube_link' );
  $youtube = !empty( $youtube ) ? $youtube : 'https://www.youtube.com/channel/UCB673uDAwz5eMUYpRgMjHHQ';
  $html = '';
  $html .= '<ul>';
  $html .= '<li><a href="' . $facebook . '" target="_blank">facebook</a></li>';
  $html .= '<li><a href="' . $instgram . '" target="_blank">instagram</a></li>';
  $html .= '<li><a href="' . $twitter . '" target="_blank">twitter</a></li>';
  $html .= '<li><a href="' . $linkedin . '" target="_blank">linkedin</a></li>';
  $html .= '<li><a href="' . $youtube . '" target="_blank">youtube</a></li>';
  $html .= '</ul>';
  return $html;
}
add_shortcode( 'social_media', 'social_link_shortcode' );


function header_social_media() {
  $facebook = get_option( 'fb_link' );
  $facebook = !empty( $facebook ) ? $facebook : 'https://www.facebook.com/vcommission';
  $instgram = get_option( 'insta_link' );
  $instgram = !empty( $instgram ) ? $instgram : 'https://www.instagram.com/vcommission.enroute/?hl=en';
  $twitter = get_option( 'twitter_link' );
  $twitter = !empty( $twitter ) ? $twitter : 'https://twitter.com/vcommission';
  $linkedin = get_option( 'linkedin_link' );
  $linkedin = !empty( $linkedin ) ? $linkedin : 'https://linkedin.com/company/vc-internet-media-pvt.-ltd.';
  $youtube = get_option( 'youtube_link' );
  $youtube = !empty( $youtube ) ? $youtube : 'https://www.youtube.com/channel/UCB673uDAwz5eMUYpRgMjHHQ';
  $html = ' <div class="left_col">';
  $brand_line = get_option( 'brand_line' );
  $brand_line = !empty( $brand_line ) ? $brand_line : 'ALL ABOUT YOUR BRAND';
  $html .= '<p>' . $brand_line . '</p></div>';
  $html .= '<div class="right_col">';
  $html .= '<ul>';
  $html .= '<li><a href="' . $facebook . '" target="_blank">facebook</a></li>';
  $html .= '<li><a href="' . $instgram . '" target="_blank">instagram</a></li>';
  $html .= '<li><a href="' . $twitter . '" target="_blank">twitter</a></li>';
  $html .= '<li><a href="' . $linkedin . '" target="_blank">linkedin</a></li>';
  $html .= '<li><a href="' . $youtube . '" target="_blank">youtube</a></li>';
  $html .= '</ul>';
  $advertiser_link = get_option( 'advertiser_link' );
  $publisher_link = get_option( 'publisher_link' );
  $html .= '</div>
	  <div class="bottom_col">
		<div class="container">
		  <div class="row">
			<ul>
			<li style=""><a href="https://network.vcommission.com/">Login</a></li>
			<li><a href="' . $advertiser_link . '">Advertiser Signup</a></li>
			<li><a href="' . $publisher_link . '">Affiliate Signup</a></li>
		  </ul> 
			<p><strong>m:</strong> <a href="mailto:hello@vcommission.com">hello{at}vcommission.com</a></p>
		  </div>
		</div>
	  </div>';
  return $html;
}
add_shortcode( 'header_social_media', 'header_social_media' );



function header_social_media_2() {
  $facebook = get_option( 'fb_link' );
  $facebook = !empty( $facebook ) ? $facebook : 'https://www.facebook.com/vcommission';
  $instgram = get_option( 'insta_link' );
  $instgram = !empty( $instgram ) ? $instgram : 'https://www.instagram.com/vcommission.enroute/?hl=en';
  $twitter = get_option( 'twitter_link' );
  $twitter = !empty( $twitter ) ? $twitter : 'https://twitter.com/vcommission';
  $linkedin = get_option( 'linkedin_link' );
  $linkedin = !empty( $linkedin ) ? $linkedin : 'https://linkedin.com/company/vc-internet-media-pvt.-ltd.';
  $youtube = get_option( 'youtube_link' );
  $youtube = !empty( $youtube ) ? $youtube : 'https://www.youtube.com/channel/UCB673uDAwz5eMUYpRgMjHHQ';
  $html = ' <div class="left_col">';
  $brand_line = get_option( 'brand_line' );
  $brand_line = !empty( $brand_line ) ? $brand_line : 'ALL ABOUT YOUR BRAND';
  $html .= '<p>' . $brand_line . '</p></div>';
  $html .= '<div class="right_col">';
  $html .= '<ul>';
  $html .= '<li><a href="' . $facebook . '" target="_blank">facebook</a></li>';
  $html .= '<li><a href="' . $instgram . '" target="_blank">instagram</a></li>';
  $html .= '<li><a href="' . $twitter . '" target="_blank">twitter</a></li>';
  $html .= '<li><a href="' . $linkedin . '" target="_blank">linkedin</a></li>';
  $html .= '<li><a href="' . $youtube . '" target="_blank">youtube</a></li>';
  $html .= '</ul>';
  $advertiser_link = get_option( 'advertiser_link' );
  $publisher_link = get_option( 'publisher_link' );
  $html .= '</div>
	  <div class="bottom_col">
		<div class="container">
		  <div class="row">
			<ul>
			<li style="margin-top:20px;"><a href="https://network.vcommission.com/">Login</a></li>
			<li><a href="' . $advertiser_link . '">Advertiser Signup</a></li>
			<li><a href="' . $publisher_link . '">Affiliate Signup</a></li>
		  </ul> 
			<p><strong>m:</strong> <a href="mailto:hello@vcommission.com">hello{at}vcommission.com</a></p>
		  </div>
		</div>
	  </div>';
  return $html;
}
add_shortcode( 'header_social_media_2', 'header_social_media_2' );


/* Theme option */
function vcom_logo_customize_register( $wp_customize ) {
  $wp_customize->add_setting( 'black_logo', array(
    'capability' => 'edit_theme_options',
    'type' => 'option',

  ) );
  $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'black_logo', array(
    'label' => __( 'Add Black color logo', 'vcommission' ),
    'section' => 'options',
    'settings' => 'black_logo',
  ) ) );

  $wp_customize->add_setting( 'white_logo', array(
    'capability' => 'edit_theme_options',
    'type' => 'option',

  ) );
  $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'white_logo', array(
    'label' => __( 'Add White color logo', 'vcommission' ),
    'section' => 'options',
    'settings' => 'white_logo',
  ) ) );

  $wp_customize->add_setting( 'brand_line', array(
    'default' => 'ALL ABOUT YOUR BRAND',
    'capability' => 'edit_theme_options',
    'type' => 'option',

  ) );

  $wp_customize->add_control( 'brand_line', array(
    'label' => __( 'Brand Line', 'vcommission' ),
    'section' => 'options',
    'settings' => 'brand_line',
  ) );

  /* === SOCICAL MEDIA SECTION ==== */
  $social_media_array = array(
    'fb_link' => 'Facebook',
    'insta_link' => 'Instagram',
    'twitter_link' => 'Twitter',
    'linkedin_link' => 'Linkedin',
    'youtube_link' => 'Youtube',
    'advertiser_link' => 'Advertisers Signup ',
    'publisher_link' => 'Publishers Signup',
  );
  foreach ( $social_media_array as $key => $social_link ) {
    $wp_customize->add_setting( $key, array(
      'capability' => 'edit_theme_options',
      'type' => 'option',
    ) );

    $wp_customize->add_control( $key, array(
      'label' => __( $social_link, 'vcommission' ),
      'section' => 'options',
      'settings' => $key,
    ) );
  }

}
add_action( 'customize_register', 'vcom_logo_customize_register' );


add_action( 'wp_enqueue_scripts', 'enqueue_parent_styles' );

 function enqueue_parent_styles() {
   wp_enqueue_style( 'parent-style', get_template_directory_uri().'/style.css' );
 }

/*filter*/
function filter_projects() {
  $catSlug = $_POST['category'];

  $ajaxposts = new WP_Query([
    'post_type' => 'post',
    'posts_per_page' => -1,
    'category_name' => $catSlug,
    'orderby' => 'menu_order', 
    'order' => 'desc',
  ]);
  $response = '';

  if($ajaxposts->have_posts()) {
    while($ajaxposts->have_posts()) : $ajaxposts->the_post();
      echo '<div class="col-md-4">';
      echo '<a href="'. get_the_permalink().' ">';
      the_post_thumbnail();
      echo '<h3>';
      the_title();
      echo '</h3>';
      echo '<span class="dates">';
      echo get_the_date( 'M d, Y' );
      echo '<div class="m-1">|';
      echo '</div>';
      echo get_the_time( 'h:i a');
      echo '</span>';
      echo '</a>';
      echo '</div>';
    endwhile;
  } else {
    $response = '<h3 class="not-found">POST NOT FOUND</h3>';
  }

  echo $response;
  exit;
}
add_action('wp_ajax_filter_projects', 'filter_projects');
add_action('wp_ajax_nopriv_filter_projects', 'filter_projects');
/*filter*/




 function vcom_team_list() {
 
  global $post;
  $args = array(
    'post_type' => 'vcommission_team',
    'post_status' => 'publish',
    'posts_per_page' => -1,
  );
 
  $loop = new WP_Query( $args ); 
  $lists = [];
  while ( $loop->have_posts() ): $loop->the_post();
  $designation = get_post_meta( $post->ID, 'designation', true );
  $title = get_the_title();
  $list['title'] = $title;
  $list['image'] = wp_get_attachment_url( get_post_thumbnail_id( $post->ID ) ) ;
  $list['designation'] = $designation;
  $lists[] = $list;
 
  endwhile;
  wp_reset_postdata();
  if (empty($lists)) {
      return new WP_Error( 'empty_category', 'There are no team to display', array('status' => 404) );
  }
    $response = new WP_REST_Response($lists);
    $response->set_status(200);
    return $response;
}







 add_action('rest_api_init', function () {
  register_rest_route( 'vCommission/v1', 'team',array(
                'methods'  => 'GET',
                'callback' => 'vcom_team_list'
      ));
});


/* create a new menu for third column, start here */
function register_menu_news() {
  register_nav_menu('menu_news',__( 'Desktop News Menu' ));
  }
  add_action( 'init', 'register_menu_news' );
/* create a new menu for third column, end here */
?>

